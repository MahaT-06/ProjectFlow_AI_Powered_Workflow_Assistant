import streamlit as st

# Function to generate mock AI suggestions based on project type
def get_mock_suggestions(project_title, project_description, project_type):
    # Static mock suggestions based on project title, description, and project type
    suggestions = f"Here is a suggested workflow for your project titled '{project_title}' with the description '{project_description}':\n\n"
    
    # Software Project Workflow
    if project_type == "Software Development":
        suggestions += "1. Define the software requirements and goals.\n"
        suggestions += "2. Break down the project into key features and modules.\n"
        suggestions += "3. Set up a development environment (IDEs, version control).\n"
        suggestions += "4. Design the software architecture and database schema.\n"
        suggestions += "5. Implement core features and functionalities.\n"
        suggestions += "6. Conduct unit testing for individual modules.\n"
        suggestions += "7. Perform integration testing and QA.\n"
        suggestions += "8. Deploy the software on servers or cloud.\n"
        suggestions += "9. Monitor the software for bugs and performance issues.\n"
        suggestions += "10. Gather user feedback and release updates.\n"

    # Web Development Project Workflow
    elif project_type == "Web Development":
        suggestions += "1. Define project scope and front-end/back-end requirements.\n"
        suggestions += "2. Design wireframes and user interface (UI).\n"
        suggestions += "3. Set up front-end (HTML, CSS, JavaScript) and back-end (e.g., Node.js, Python).\n"
        suggestions += "4. Set up databases (e.g., MySQL, MongoDB).\n"
        suggestions += "5. Implement key features and functionality (e.g., user authentication, databases).\n"
        suggestions += "6. Perform cross-browser and mobile compatibility testing.\n"
        suggestions += "7. Deploy the website using cloud services (e.g., AWS, Heroku).\n"
        suggestions += "8. Monitor website uptime and user interactions.\n"
        suggestions += "9. Implement SEO strategies for better ranking.\n"
        suggestions += "10. Collect user feedback and iterate on the design.\n"

    # Research Project Workflow
    elif project_type == "Research":
        suggestions += "1. Define research hypothesis and objectives.\n"
        suggestions += "2. Conduct a literature review on the topic.\n"
        suggestions += "3. Design experiments or surveys for data collection.\n"
        suggestions += "4. Analyze data using statistical tools.\n"
        suggestions += "5. Draw conclusions based on data analysis.\n"
        suggestions += "6. Write a research paper detailing findings.\n"
        suggestions += "7. Submit paper to relevant journals or conferences.\n"
        suggestions += "8. Present research findings in seminars or conferences.\n"
        suggestions += "9. Gather feedback and refine the research.\n"
        suggestions += "10. Apply research results to real-world applications.\n"

    # Business Development Project Workflow
    elif project_type == "Business Development":
        suggestions += "1. Conduct market research to identify opportunities.\n"
        suggestions += "2. Define the business goals and target audience.\n"
        suggestions += "3. Develop a business plan and strategy.\n"
        suggestions += "4. Identify key performance indicators (KPIs) to track progress.\n"
        suggestions += "5. Set up marketing and outreach strategies (social media, email campaigns).\n"
        suggestions += "6. Launch the product or service to the market.\n"
        suggestions += "7. Monitor customer feedback and address concerns.\n"
        suggestions += "8. Evaluate the effectiveness of the business strategies.\n"
        suggestions += "9. Scale the business and expand customer base.\n"
        suggestions += "10. Continuously improve product/services based on market feedback.\n"

    else:
        suggestions += "1. Define the project scope and key objectives.\n"
        suggestions += "2. Break down the project into smaller tasks.\n"
        suggestions += "3. Set up project management tools (e.g., Trello, Jira, Asana).\n"
        suggestions += "4. Allocate tasks and assign responsibilities.\n"
        suggestions += "5. Monitor progress and update timelines.\n"
        suggestions += "6. Test and validate the project output.\n"
        suggestions += "7. Document the project for future reference.\n"
        suggestions += "8. Deliver the final project and gather feedback.\n"
        suggestions += "9. Review lessons learned and areas for improvement.\n"
        suggestions += "10. Celebrate the success and conclude the project.\n"

    return suggestions

# Streamlit UI setup
st.title("ProjectFlow: AI-Powered Workflow Assistant")

st.write("Enter your project details to get workflow suggestions based on the project type.")

# Project title, description, and type inputs
project_title = st.text_input("Project Title")
project_description = st.text_area("Project Description")

# Project type selection (Software, Web Development, Research, etc.)
project_type = st.selectbox(
    "Select Project Type",
    ["Software Development", "Web Development", "Research", "Business Development", "Other"]
)

# Button to generate workflow suggestions
if st.button("Get Workflow"):
    if project_title and project_description:
        # Generate mock suggestions based on project type
        suggestions = get_mock_suggestions(project_title, project_description, project_type)
        
        # Display the AI-generated workflow
        st.subheader("Suggested Workflow")
        st.write(suggestions)
    else:
        st.warning("Please enter both the project title and description.")
